# ともだちAI

Полностью локальный AI-чат для Android. Все данные хранятся только на устройстве.

## Сборка через GitHub Actions (без ПК)

1. Создай репозиторий на GitHub (github.com → New repository)
2. Загрузи все файлы из этого архива
3. Перейди во вкладку **Actions** → выбери **Build APK** → нажми **Run workflow**
4. Через ~5-10 минут скачай APK из раздела **Artifacts**

## Сборка через Android Studio (с ПК)

1. Открой папку в Android Studio
2. Build → Generate Signed / Debug APK

## Использование

1. Скачай модель: `gemma-3-4b-it-q4_k_m.gguf` с HuggingFace
2. Положи файл в любую папку телефона
3. В приложении → Настройки → Выбрать файл модели
4. Начни общение!

## Ссылка на модель

https://huggingface.co/google/gemma-3-4b-it-GGUF

## Технологии

- Kotlin + Jetpack Compose
- MediaPipe LLM Inference (движок)
- Room Database (история чатов)
- DataStore (настройки)
- 100% локально, без интернета во время работы
