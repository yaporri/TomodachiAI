package com.tomodachi.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "tomodachi_prefs")

object PrefsKeys {
    val DARK_THEME = booleanPreferencesKey("dark_theme")
    val LANGUAGE = stringPreferencesKey("language")          // "ru" | "en"
    val MODEL_PATH = stringPreferencesKey("model_path")
    val MODEL_LOADED = booleanPreferencesKey("model_loaded")
    val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val MAX_TOKENS = intPreferencesKey("max_tokens")
}

class UserPreferences(private val context: Context) {

    val darkTheme: Flow<Boolean> = context.dataStore.data.map {
        it[PrefsKeys.DARK_THEME] ?: true
    }
    val language: Flow<String> = context.dataStore.data.map {
        it[PrefsKeys.LANGUAGE] ?: "ru"
    }
    val modelPath: Flow<String> = context.dataStore.data.map {
        it[PrefsKeys.MODEL_PATH] ?: ""
    }
    val modelLoaded: Flow<Boolean> = context.dataStore.data.map {
        it[PrefsKeys.MODEL_LOADED] ?: false
    }
    val systemPrompt: Flow<String> = context.dataStore.data.map {
        it[PrefsKeys.SYSTEM_PROMPT] ?: ""
    }
    val temperature: Flow<Float> = context.dataStore.data.map {
        it[PrefsKeys.TEMPERATURE] ?: 0.8f
    }
    val maxTokens: Flow<Int> = context.dataStore.data.map {
        it[PrefsKeys.MAX_TOKENS] ?: 512
    }

    suspend fun setDarkTheme(value: Boolean) {
        context.dataStore.edit { it[PrefsKeys.DARK_THEME] = value }
    }
    suspend fun setLanguage(value: String) {
        context.dataStore.edit { it[PrefsKeys.LANGUAGE] = value }
    }
    suspend fun setModelPath(value: String) {
        context.dataStore.edit { it[PrefsKeys.MODEL_PATH] = value }
    }
    suspend fun setModelLoaded(value: Boolean) {
        context.dataStore.edit { it[PrefsKeys.MODEL_LOADED] = value }
    }
    suspend fun setSystemPrompt(value: String) {
        context.dataStore.edit { it[PrefsKeys.SYSTEM_PROMPT] = value }
    }
    suspend fun setTemperature(value: Float) {
        context.dataStore.edit { it[PrefsKeys.TEMPERATURE] = value }
    }
    suspend fun setMaxTokens(value: Int) {
        context.dataStore.edit { it[PrefsKeys.MAX_TOKENS] = value }
    }
}
