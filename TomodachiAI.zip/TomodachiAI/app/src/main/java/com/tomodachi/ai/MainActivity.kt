package com.tomodachi.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.*
import com.tomodachi.ai.data.AppDatabase
import com.tomodachi.ai.ui.chat.ChatScreen
import com.tomodachi.ai.ui.chat.ChatViewModel
import com.tomodachi.ai.ui.chat.HistoryScreen
import com.tomodachi.ai.ui.settings.SettingsScreen
import com.tomodachi.ai.ui.theme.TomodachiTheme

class MainActivity : ComponentActivity() {

    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            val darkTheme by viewModel.darkTheme.collectAsState()
            val db = remember { AppDatabase.getInstance(this) }

            TomodachiTheme(darkTheme = darkTheme) {
                AppNavigation(viewModel = viewModel, db = db)
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: ChatViewModel, db: AppDatabase) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "chat") {
        composable("chat") {
            ChatScreen(
                viewModel = viewModel,
                onOpenSettings = { navController.navigate("settings") },
                onOpenHistory = { navController.navigate("history") }
            )
        }
        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("history") {
            HistoryScreen(
                viewModel = viewModel,
                db = db,
                onBack = { navController.popBackStack() },
                onSelectConversation = { id ->
                    viewModel.loadConversation(id)
                    navController.popBackStack()
                }
            )
        }
    }
}
