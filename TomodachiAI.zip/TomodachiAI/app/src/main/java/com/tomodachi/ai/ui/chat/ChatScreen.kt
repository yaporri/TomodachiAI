package com.tomodachi.ai.ui.chat

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tomodachi.ai.llm.LlmState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
) {
    val messages by viewModel.messages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val llmState by viewModel.llmState.collectAsState()
    val lang by viewModel.language.collectAsState()

    val listState = rememberLazyListState()

    // Auto-scroll to bottom
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val colors = MaterialTheme.colorScheme

    Scaffold(
        containerColor = colors.background,
        topBar = {
            TopBar(
                lang = lang,
                llmState = llmState,
                onSettings = onOpenSettings,
                onHistory = onOpenHistory,
                onNewChat = { viewModel.startNewConversation() },
                colors = colors
            )
        },
        bottomBar = {
            InputBar(
                text = inputText,
                isGenerating = isGenerating,
                isReady = llmState is LlmState.Ready,
                lang = lang,
                colors = colors,
                onTextChange = viewModel::onInputChange,
                onSend = viewModel::sendMessage,
                onStop = viewModel::stopGeneration,
            )
        }
    ) { padding ->
        if (messages.isEmpty()) {
            EmptyState(lang = lang, llmState = llmState, colors = colors, modifier = Modifier.padding(padding))
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(messages, key = { it.id.toString() + it.timestamp }) { msg ->
                    MessageBubble(msg = msg, colors = colors)
                }
            }
        }
    }
}

@Composable
private fun TopBar(
    lang: String,
    llmState: LlmState,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
    onNewChat: () -> Unit,
    colors: ColorScheme
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onHistory) {
                Icon(Icons.Outlined.ChatBubbleOutline, null, tint = colors.onBackground)
            }

            Spacer(Modifier.weight(1f))

            // App name
            Text(
                text = "ともだちAI",
                style = MaterialTheme.typography.titleLarge,
                color = colors.onBackground,
                letterSpacing = (-0.5).sp
            )

            Spacer(Modifier.weight(1f))

            IconButton(onClick = onNewChat) {
                Icon(Icons.Outlined.Add, null, tint = colors.onBackground)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Outlined.Settings, null, tint = colors.onBackground)
            }
        }

        // Status indicator
        StatusBar(llmState = llmState, lang = lang, colors = colors)

        HorizontalDivider(color = colors.outline, thickness = 0.5.dp)
    }
}

@Composable
private fun StatusBar(llmState: LlmState, lang: String, colors: ColorScheme) {
    val (text, dotColor) = when (llmState) {
        is LlmState.Ready -> {
            val name = llmState.modelName.take(24)
            (if (lang == "ru") "Готов · $name" else "Ready · $name") to Color(0xFF4CAF50)
        }
        is LlmState.Loading ->
            (if (lang == "ru") "Загрузка модели…" else "Loading model…") to Color(0xFFFF9800)
        is LlmState.Error ->
            (if (lang == "ru") "Ошибка: ${llmState.message.take(30)}" else "Error: ${llmState.message.take(30)}") to Color(0xFFF44336)
        is LlmState.Generating ->
            (if (lang == "ru") "Генерация…" else "Generating…") to Color(0xFF2196F3)
        else ->
            (if (lang == "ru") "Модель не загружена" else "No model loaded") to colors.outline
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(50))
                .background(dotColor)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = colors.secondary
        )
    }
}

@Composable
private fun MessageBubble(msg: UiMessage, colors: ColorScheme) {
    val isUser = msg.role == "user"

    // Blinking cursor for streaming
    val cursor = if (msg.isStreaming) {
        val infiniteTransition = rememberInfiniteTransition(label = "cursor")
        val alpha by infiniteTransition.animateFloat(
            initialValue = 1f, targetValue = 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(500),
                repeatMode = RepeatMode.Reverse
            ), label = "cursorAlpha"
        )
        "▋".let { if (alpha > 0.5f) it else "" }
    } else ""

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // AI icon
            Box(
                modifier = Modifier
                    .padding(end = 8.dp, top = 4.dp)
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.surface),
                contentAlignment = Alignment.Center
            ) {
                Text("友", fontSize = 14.sp, color = colors.onSurface)
            }
        }

        Box(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = if (isUser) 18.dp else 4.dp,
                        topEnd = if (isUser) 4.dp else 18.dp,
                        bottomStart = 18.dp,
                        bottomEnd = 18.dp
                    )
                )
                .background(
                    if (isUser) colors.onBackground.copy(alpha = 0.9f)
                    else colors.surfaceVariant
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = msg.content + cursor,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isUser) colors.background else colors.onSurface,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun EmptyState(lang: String, llmState: LlmState, colors: ColorScheme, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "ともだちAI",
                style = MaterialTheme.typography.titleLarge,
                color = colors.onBackground.copy(alpha = 0.15f),
                fontSize = 32.sp
            )
            Spacer(Modifier.height(16.dp))
            if (llmState !is LlmState.Ready) {
                Text(
                    text = if (lang == "ru")
                        "Загрузите модель в Настройках\nдля начала общения"
                    else
                        "Load a model in Settings\nto start chatting",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.secondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
            } else {
                Text(
                    text = if (lang == "ru") "Напишите что-нибудь…" else "Say something…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.secondary
                )
            }
        }
    }
}

@Composable
private fun InputBar(
    text: String,
    isGenerating: Boolean,
    isReady: Boolean,
    lang: String,
    colors: ColorScheme,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    Column {
        HorizontalDivider(color = colors.outline, thickness = 0.5.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        if (!isReady)
                            (if (lang == "ru") "Загрузите модель…" else "Load a model…")
                        else
                            (if (lang == "ru") "Сообщение" else "Message"),
                        color = colors.secondary
                    )
                },
                enabled = isReady && !isGenerating,
                maxLines = 6,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.outline,
                    unfocusedBorderColor = colors.outline.copy(alpha = 0.4f),
                    cursorColor = colors.onBackground,
                    focusedTextColor = colors.onBackground,
                    unfocusedTextColor = colors.onBackground,
                    disabledBorderColor = colors.outline.copy(alpha = 0.2f),
                    disabledTextColor = colors.secondary,
                )
            )

            Spacer(Modifier.width(8.dp))

            // Send / Stop button
            FilledIconButton(
                onClick = if (isGenerating) onStop else onSend,
                modifier = Modifier.size(48.dp),
                enabled = isReady && (isGenerating || text.isNotBlank()),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = colors.onBackground,
                    contentColor = colors.background,
                    disabledContainerColor = colors.surfaceVariant,
                    disabledContentColor = colors.secondary,
                )
            ) {
                Icon(
                    imageVector = if (isGenerating) Icons.Outlined.Stop else Icons.Outlined.ArrowUpward,
                    contentDescription = null
                )
            }
        }
    }
}
