package com.tomodachi.ai.ui.chat

import android.app.Application
import androidx.lifecycle.*
import com.tomodachi.ai.data.*
import com.tomodachi.ai.llm.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class UiMessage(
    val id: Long = 0,
    val role: String,
    val content: String,
    val isStreaming: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val prefs = UserPreferences(application)
    val engine = LlmEngine(application)

    // ── State ─────────────────────────────────────────────────────────────────
    private val _messages = MutableStateFlow<List<UiMessage>>(emptyList())
    val messages: StateFlow<List<UiMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    val llmState = engine.state

    private var currentConversationId: Long = -1
    private var generationJob: Job? = null

    // ── Prefs ─────────────────────────────────────────────────────────────────
    val language = prefs.language.stateIn(viewModelScope, SharingStarted.Eagerly, "ru")
    val darkTheme = prefs.darkTheme.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val systemPrompt = prefs.systemPrompt.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val temperature = prefs.temperature.stateIn(viewModelScope, SharingStarted.Eagerly, 0.8f)
    val maxTokens = prefs.maxTokens.stateIn(viewModelScope, SharingStarted.Eagerly, 512)

    init {
        // Auto-load model if previously set
        viewModelScope.launch {
            val path = prefs.modelPath.first()
            if (path.isNotBlank()) {
                loadModel(path)
            }
        }
        startNewConversation()
    }

    // ── Model ─────────────────────────────────────────────────────────────────
    fun loadModel(path: String) {
        viewModelScope.launch {
            val config = GenerationConfig(
                temperature = temperature.value,
                maxTokens = maxTokens.value
            )
            engine.loadModel(path, config)
            prefs.setModelPath(path)
            prefs.setModelLoaded(engine.isReady())
        }
    }

    // ── Conversation ──────────────────────────────────────────────────────────
    fun startNewConversation() {
        viewModelScope.launch {
            val conv = Conversation()
            currentConversationId = db.conversationDao().insert(conv)
            _messages.value = emptyList()
        }
    }

    fun loadConversation(id: Long) {
        viewModelScope.launch {
            currentConversationId = id
            val msgs = db.messageDao().getMessages(id).first()
            _messages.value = msgs.map {
                UiMessage(id = it.id, role = it.role, content = it.content, timestamp = it.timestamp)
            }
        }
    }

    // ── Input ─────────────────────────────────────────────────────────────────
    fun onInputChange(text: String) {
        _inputText.value = text
    }

    // ── Send ──────────────────────────────────────────────────────────────────
    fun sendMessage() {
        val text = _inputText.value.trim()
        if (text.isBlank() || _isGenerating.value) return
        if (!engine.isReady()) return

        _inputText.value = ""

        viewModelScope.launch {
            // Add user message
            val userMsg = UiMessage(role = "user", content = text)
            _messages.value = _messages.value + userMsg

            // Save to DB
            db.messageDao().insert(
                Message(conversationId = currentConversationId, role = "user", content = text)
            )

            // Update conversation title if first message
            if (_messages.value.size == 1) {
                val title = text.take(40)
                db.conversationDao().update(
                    Conversation(id = currentConversationId, title = title,
                        updatedAt = System.currentTimeMillis())
                )
            }

            // Add streaming placeholder
            val streamingMsg = UiMessage(role = "assistant", content = "", isStreaming = true)
            _messages.value = _messages.value + streamingMsg
            _isGenerating.value = true

            // Build history for context
            val history = _messages.value
                .filter { !it.isStreaming }
                .map { it.role to it.content }

            var fullResponse = ""

            generationJob = launch {
                engine.generateStream(history, systemPrompt.value)
                    .collect { token ->
                        fullResponse += token
                        // Update streaming message
                        _messages.value = _messages.value.dropLast(1) +
                                streamingMsg.copy(content = fullResponse, isStreaming = true)
                    }

                // Finalize
                _messages.value = _messages.value.dropLast(1) +
                        UiMessage(role = "assistant", content = fullResponse, isStreaming = false)

                // Save to DB
                db.messageDao().insert(
                    Message(conversationId = currentConversationId,
                        role = "assistant", content = fullResponse)
                )

                _isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        generationJob?.cancel()
        _isGenerating.value = false
        // Mark last message as done
        val msgs = _messages.value.toMutableList()
        val last = msgs.lastOrNull()
        if (last?.isStreaming == true) {
            msgs[msgs.size - 1] = last.copy(isStreaming = false)
            _messages.value = msgs
        }
    }

    fun clearCurrentChat() {
        viewModelScope.launch {
            db.messageDao().deleteByConversation(currentConversationId)
            _messages.value = emptyList()
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────
    fun setDarkTheme(value: Boolean) = viewModelScope.launch { prefs.setDarkTheme(value) }
    fun setLanguage(value: String) = viewModelScope.launch { prefs.setLanguage(value) }
    fun setSystemPrompt(value: String) = viewModelScope.launch { prefs.setSystemPrompt(value) }
    fun setTemperature(value: Float) = viewModelScope.launch { prefs.setTemperature(value) }
    fun setMaxTokens(value: Int) = viewModelScope.launch { prefs.setMaxTokens(value) }

    override fun onCleared() {
        super.onCleared()
        engine.close()
    }
}
