package com.tomodachi.ai.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tomodachi.ai.llm.LlmState
import com.tomodachi.ai.ui.chat.ChatViewModel

@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
) {
    val lang by viewModel.language.collectAsState()
    val darkTheme by viewModel.darkTheme.collectAsState()
    val llmState by viewModel.llmState.collectAsState()
    val systemPrompt by viewModel.systemPrompt.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val maxTokens by viewModel.maxTokens.collectAsState()
    val colors = MaterialTheme.colorScheme

    var promptText by remember(systemPrompt) { mutableStateOf(systemPrompt) }
    var tempText by remember(temperature) { mutableStateOf(temperature.toString()) }

    // File picker for model
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            val path = getRealPath(it)
            if (path != null) viewModel.loadModel(path)
        }
    }

    fun getRealPath(uri: Uri): String? {
        // For scoped storage we use the URI path directly
        return uri.path
    }

    val isRu = lang == "ru"

    Scaffold(
        containerColor = colors.background,
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBackIosNew, null, tint = colors.onBackground)
                    }
                    Text(
                        text = if (isRu) "Настройки" else "Settings",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.onBackground
                    )
                }
                HorizontalDivider(color = colors.outline, thickness = 0.5.dp)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // ── Language ──────────────────────────────────────────────────────
            SectionLabel(if (isRu) "Язык" else "Language", colors)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.surfaceVariant),
            ) {
                listOf("ru" to "Русский", "en" to "English").forEach { (code, label) ->
                    val selected = lang == code
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) colors.onBackground else Color.Transparent)
                            .clickable { viewModel.setLanguage(code) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            color = if (selected) colors.background else colors.secondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // ── Appearance ────────────────────────────────────────────────────
            SectionLabel(if (isRu) "Внешний вид" else "Appearance", colors)
            SettingRow(
                label = if (isRu) "Тёмная тема" else "Dark Theme",
                colors = colors
            ) {
                Switch(
                    checked = darkTheme,
                    onCheckedChange = viewModel::setDarkTheme,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.background,
                        checkedTrackColor = colors.onBackground,
                        uncheckedThumbColor = colors.secondary,
                        uncheckedTrackColor = colors.surfaceVariant,
                    )
                )
            }

            // ── Model ─────────────────────────────────────────────────────────
            SectionLabel(if (isRu) "Модель" else "Model", colors)

            // Status chip
            ModelStatusChip(llmState = llmState, lang = lang, colors = colors)

            // Load model button
            OutlinedButton(
                onClick = { filePicker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, colors.outline)
            ) {
                Icon(Icons.Outlined.FolderOpen, null, Modifier.size(16.dp), tint = colors.onBackground)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (isRu) "Выбрать файл .gguf модели" else "Select .gguf model file",
                    color = colors.onBackground,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Model path hint
            Text(
                text = if (isRu)
                    "Скачайте Gemma-3-4B-IT-Q4.gguf с HuggingFace\nи выберите файл здесь"
                else
                    "Download Gemma-3-4B-IT-Q4.gguf from HuggingFace\nand select it here",
                style = MaterialTheme.typography.labelSmall,
                color = colors.secondary,
                lineHeight = 18.sp
            )

            // ── Generation ────────────────────────────────────────────────────
            SectionLabel(if (isRu) "Генерация" else "Generation", colors)

            // Temperature
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (isRu) "Температура" else "Temperature",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onBackground,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "%.1f".format(temperature),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.secondary
                    )
                }
                Slider(
                    value = temperature,
                    onValueChange = viewModel::setTemperature,
                    valueRange = 0.1f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.onBackground,
                        activeTrackColor = colors.onBackground,
                        inactiveTrackColor = colors.surfaceVariant
                    )
                )
            }

            // Max tokens
            Column {
                Text(
                    if (isRu) "Макс. токенов: $maxTokens" else "Max tokens: $maxTokens",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onBackground
                )
                Slider(
                    value = maxTokens.toFloat(),
                    onValueChange = { viewModel.setMaxTokens(it.toInt()) },
                    valueRange = 128f..2048f,
                    steps = 14,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.onBackground,
                        activeTrackColor = colors.onBackground,
                        inactiveTrackColor = colors.surfaceVariant
                    )
                )
            }

            // ── System Prompt ─────────────────────────────────────────────────
            SectionLabel(if (isRu) "Системный промпт" else "System Prompt", colors)
            OutlinedTextField(
                value = promptText,
                onValueChange = { promptText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 80.dp),
                placeholder = {
                    Text(
                        if (isRu) "Опционально. Например: Отвечай кратко."
                        else "Optional. e.g. Reply concisely.",
                        color = colors.secondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                shape = RoundedCornerShape(12.dp),
                maxLines = 6,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.outline,
                    unfocusedBorderColor = colors.outline.copy(alpha = 0.4f),
                    cursorColor = colors.onBackground,
                    focusedTextColor = colors.onBackground,
                    unfocusedTextColor = colors.onBackground,
                )
            )
            OutlinedButton(
                onClick = { viewModel.setSystemPrompt(promptText) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, colors.outline)
            ) {
                Text(
                    if (isRu) "Сохранить" else "Save",
                    color = colors.onBackground,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // ── Privacy note ──────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.surfaceVariant)
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        Icons.Outlined.Lock, null,
                        modifier = Modifier.size(16.dp),
                        tint = colors.secondary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (isRu)
                            "Все данные хранятся только на вашем устройстве. Никакие данные не передаются в интернет."
                        else
                            "All data is stored locally on your device. No data is ever sent to the internet.",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.secondary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String, colors: ColorScheme) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = colors.secondary,
        letterSpacing = 1.2.sp
    )
}

@Composable
private fun SettingRow(label: String, colors: ColorScheme, control: @Composable () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.onBackground, modifier = Modifier.weight(1f))
        control()
    }
}

@Composable
private fun ModelStatusChip(llmState: LlmState, lang: String, colors: ColorScheme) {
    val isRu = lang == "ru"
    val (text, bg) = when (llmState) {
        is LlmState.Ready -> (if (isRu) "✓ Модель загружена" else "✓ Model loaded") to colors.surfaceVariant
        is LlmState.Loading -> (if (isRu) "⏳ Загрузка…" else "⏳ Loading…") to colors.surfaceVariant
        is LlmState.Error -> (if (isRu) "✗ Ошибка" else "✗ Error") to colors.surfaceVariant
        else -> (if (isRu) "Модель не загружена" else "No model loaded") to colors.surfaceVariant
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = colors.secondary)
    }
}
