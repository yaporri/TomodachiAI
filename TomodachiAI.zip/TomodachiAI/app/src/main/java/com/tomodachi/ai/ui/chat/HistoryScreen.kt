package com.tomodachi.ai.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.tomodachi.ai.data.AppDatabase
import com.tomodachi.ai.data.Conversation
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    viewModel: ChatViewModel,
    db: AppDatabase,
    onBack: () -> Unit,
    onSelectConversation: (Long) -> Unit,
) {
    val lang by viewModel.language.collectAsState()
    val isRu = lang == "ru"
    val conversations by db.conversationDao().getAll().collectAsState(initial = emptyList())
    val colors = MaterialTheme.colorScheme

    Scaffold(
        containerColor = colors.background,
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBackIosNew, null, tint = colors.onBackground)
                    }
                    Text(
                        if (isRu) "История" else "History",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.onBackground
                    )
                }
                HorizontalDivider(color = colors.outline, thickness = 0.5.dp)
            }
        }
    ) { padding ->
        if (conversations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (isRu) "Нет сохранённых чатов" else "No saved chats",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.secondary
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(conversations, key = { it.id }) { conv ->
                    ConversationItem(
                        conv = conv,
                        colors = colors,
                        onClick = { onSelectConversation(conv.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationItem(
    conv: Conversation,
    colors: ColorScheme,
    onClick: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = conv.title.ifBlank { "Untitled" },
                style = MaterialTheme.typography.bodyMedium,
                color = colors.onSurface,
                maxLines = 1
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = formatter.format(Date(conv.updatedAt)),
                style = MaterialTheme.typography.labelSmall,
                color = colors.secondary
            )
        }
        Icon(
            Icons.Outlined.ChevronRight, null,
            tint = colors.secondary,
            modifier = Modifier.size(16.dp)
        )
    }
}
