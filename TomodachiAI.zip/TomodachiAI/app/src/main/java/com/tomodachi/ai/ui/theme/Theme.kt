package com.tomodachi.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Palette ──────────────────────────────────────────────────────────────────
val Black = Color(0xFF0A0A0A)
val White = Color(0xFFF5F5F5)
val OffWhite = Color(0xFFEEEEEE)
val LightGray = Color(0xFFD4D4D4)
val MidGray = Color(0xFF888888)
val DarkGray = Color(0xFF1A1A1A)
val UserBubble = Color(0xFF1A1A1A)
val AiBubble = Color(0xFFF0F0F0)
val AccentLine = Color(0xFF3A3A3A)

// ── Dark Scheme ───────────────────────────────────────────────────────────────
val DarkColors = darkColorScheme(
    primary = White,
    onPrimary = Black,
    background = Black,
    onBackground = White,
    surface = DarkGray,
    onSurface = White,
    surfaceVariant = Color(0xFF222222),
    onSurfaceVariant = LightGray,
    outline = Color(0xFF333333),
    secondary = MidGray,
    onSecondary = White,
)

// ── Light Scheme ──────────────────────────────────────────────────────────────
val LightColors = lightColorScheme(
    primary = Black,
    onPrimary = White,
    background = White,
    onBackground = Black,
    surface = OffWhite,
    onSurface = Black,
    surfaceVariant = Color(0xFFE8E8E8),
    onSurfaceVariant = Color(0xFF444444),
    outline = LightGray,
    secondary = MidGray,
    onSecondary = Black,
)

@Composable
fun TomodachiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = TomodachiTypography,
        content = content
    )
}
