package com.tomodachi.ai.llm

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

private const val TAG = "TomodachiLLM"

data class GenerationConfig(
    val temperature: Float = 0.8f,
    val maxTokens: Int = 512,
    val topK: Int = 40,
    val topP: Float = 0.95f,
)

sealed class LlmState {
    object Idle : LlmState()
    object Loading : LlmState()
    data class Ready(val modelName: String) : LlmState()
    data class Error(val message: String) : LlmState()
    object Generating : LlmState()
}

class LlmEngine(private val context: Context) {

    private var inference: LlmInference? = null
    private val _state = MutableStateFlow<LlmState>(LlmState.Idle)
    val state: StateFlow<LlmState> = _state.asStateFlow()

    suspend fun loadModel(modelPath: String, config: GenerationConfig = GenerationConfig()) {
        _state.value = LlmState.Loading
        withContext(Dispatchers.IO) {
            try {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelPath)
                    .setMaxTokens(config.maxTokens)
                    .setTemperature(config.temperature)
                    .setTopK(config.topK)
                    .setRandomSeed(System.currentTimeMillis().toInt())
                    .build()

                inference?.close()
                inference = LlmInference.createFromOptions(context, options)
                val name = modelPath.substringAfterLast("/")
                _state.value = LlmState.Ready(name)
                Log.i(TAG, "Model loaded: $name")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load model", e)
                _state.value = LlmState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun generateStream(
        messages: List<Pair<String, String>>, // role, content
        systemPrompt: String = "",
    ): Flow<String> = flow {
        val engine = inference ?: run {
            emit("[ERROR] Model not loaded")
            return@flow
        }

        _state.value = LlmState.Generating

        // Build prompt in ChatML format (works with Gemma/Llama)
        val prompt = buildPrompt(messages, systemPrompt)

        val channel = Channel<String>(Channel.UNLIMITED)

        withContext(Dispatchers.IO) {
            try {
                engine.generateResponseAsync(prompt) { partial, done ->
                    if (partial != null) channel.trySend(partial)
                    if (done) channel.close()
                }
            } catch (e: Exception) {
                channel.close(e)
            }
        }

        for (token in channel) {
            emit(token)
        }

        _state.value = LlmState.Ready(
            (state.value as? LlmState.Ready)?.modelName ?: ""
        )
    }.flowOn(Dispatchers.IO)

    private fun buildPrompt(
        messages: List<Pair<String, String>>,
        systemPrompt: String
    ): String {
        val sb = StringBuilder()

        // Gemma format
        if (systemPrompt.isNotBlank()) {
            sb.append("<start_of_turn>system\n$systemPrompt<end_of_turn>\n")
        }

        messages.forEach { (role, content) ->
            val r = if (role == "user") "user" else "model"
            sb.append("<start_of_turn>$r\n$content<end_of_turn>\n")
        }
        sb.append("<start_of_turn>model\n")

        return sb.toString()
    }

    fun isReady() = state.value is LlmState.Ready

    fun close() {
        inference?.close()
        inference = null
        _state.value = LlmState.Idle
    }
}
